#include <global_settings.h>

int main()
{
	return 0;
}