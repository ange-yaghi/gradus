#ifndef GR_ARRAY_H
#define GR_ARRAY_H

#include <memory>

class grDynamicArrayElement
{

public:

	grDynamicArrayElement()
	{

		m_index = -1;
		m_alignment = 0;

	}

	~grDynamicArrayElement()
	{
	}

	inline int GetIndex() const
	{

		return m_index;

	}

	inline void SetIndex(int index)
	{

		m_index = index;

	}

	inline int GetAlignment() const
	{

		return m_alignment;

	}

	inline void SetAlignment(int alignment)
	{

		m_alignment = alignment;

	}

protected:

	int m_index;
	int m_alignment;

};

template<typename TYPE, int START_SIZE = 0>
class grDynamicArray
{

public:

	enum ERROR_CODE
	{
		ERROR_NO_ERROR,
		ERROR_OUT_OF_BOUNDS
	};

public:

	grDynamicArray()
	{

		m_maxSize = START_SIZE;
		m_nObjects = 0;
		m_array = NULL;

		Preallocate(m_maxSize);

	}

	~grDynamicArray()
	{

		Clear();
		delete[] m_array;

	}

	void Preallocate(int nObjects)
	{

		if (!nObjects) return;
		if (m_array) return;

		m_array = new TYPE *[nObjects];

	}

	TYPE *New()
	{

		if (m_nObjects >= m_maxSize) Extend();

		m_array[m_nObjects] = new TYPE;

		// Cast to a standard array element
		grDynamicArrayElement *sElement = static_cast<grDynamicArrayElement *>(m_array[m_nObjects]);
		sElement->SetAlignment(0);
		sElement->SetIndex(m_nObjects);

		return m_array[m_nObjects++];

	}

	void Add(TYPE *type)
	{

		if (m_nObjects >= m_maxSize) Extend();

		m_array[m_nObjects] = type;

		// Cast to a standard array element
		grDynamicArrayElement *sElement = static_cast<grDynamicArrayElement *>(m_array[m_nObjects]);
		sElement->SetIndex(m_nObjects);

		m_nObjects++;

	}

	void Add(TYPE *type, int offset)
	{

		if (m_nObjects >= m_maxSize) Extend();

		// Make room
		for (int i = m_nObjects; i > offset; i--)
		{

			m_array[i] = m_array[i - 1];

		}

		m_array[offset] = type;

		// Cast to a standard array element
		grDynamicArrayElement *sElement = static_cast<grDynamicArrayElement *>(m_array[offset]);
		sElement->SetIndex(offset);

		m_nObjects++;

	}

	void Move(TYPE *type, int offset)
	{

		// Make room
		for (int i = m_nObjects - 1; i > offset; i--)
		{

			m_array[i] = m_array[i - 1];

		}

		m_array[offset] = type;

		// Cast to a standard array element
		grDynamicArrayElement *sElement = static_cast<grDynamicArrayElement *>(m_array[offset]);
		sElement->SetIndex(offset);

	}

	template<typename DYN_TYPE>
	DYN_TYPE *NewGeneric(int alignment = 0)
	{

		if (m_nObjects >= m_maxSize) Extend();

		if (alignment != 0)
		{

			void *memory = _aligned_malloc(sizeof(DYN_TYPE), alignment);
			m_array[m_nObjects] = static_cast<TYPE *>(new (memory) DYN_TYPE);

		}

		else m_array[m_nObjects] = static_cast<TYPE *>(new DYN_TYPE);

		// Cast to a standard array element
		grDynamicArrayElement *sElement = static_cast<grDynamicArrayElement *>(m_array[m_nObjects]);
		sElement->SetAlignment(alignment);
		sElement->SetIndex(m_nObjects);

		return static_cast<DYN_TYPE *>(m_array[m_nObjects++]);

	}

	ERROR_CODE Delete(int index, bool destroy = true, TYPE *replacement = NULL, bool preserveOrder = false)
	{

		if (index >= m_nObjects || index < 0) return ERROR_CODE::ERROR_OUT_OF_BOUNDS;

		if (m_nObjects <= m_maxSize / 2) Condense();

		grDynamicArrayElement *target = static_cast<grDynamicArrayElement *>(m_array[index]);

		if (destroy)
		{

			if (target->GetAlignment() == 0)
			{

				delete m_array[index];

			}

			else
			{

				m_array[index]->~TYPE();
				_aligned_free(m_array[index]);

			}

		}

		if (replacement == NULL)
		{

			if (!preserveOrder)
			{

				m_array[index] = m_array[m_nObjects - 1];
				m_array[m_nObjects - 1] = NULL;

			}

			else
			{

				for (int i = index; i < m_nObjects - 1; i++)
				{

					m_array[i] = m_array[i + 1];

					grDynamicArrayElement *sElement = static_cast<grDynamicArrayElement *>(m_array[i]);
					sElement->SetIndex(i);

				}

				// Just as a precaution
				m_array[m_nObjects - 1] = NULL;

			}

		}

		else
		{

			m_array[index] = replacement;

		}

		// Cast to a standard array element
		if (m_array[index])
		{

			grDynamicArrayElement *sElement = static_cast<grDynamicArrayElement *>(m_array[index]);
			sElement->SetIndex(index);

		}

		if (replacement == NULL)
		{

			m_nObjects--;

		}

		return ERROR_CODE::ERROR_NO_ERROR;

	}

	inline TYPE * Get(int index) const
	{

		return m_array[index];

	}

	inline TYPE **GetBuffer()
	{

		return m_array;

	}

	int GetNumObjects() const
	{

		return m_nObjects;

	}

	void Clear(bool destroy = true)
	{

		if (destroy)
		{

			int nObjects = m_nObjects;
			for (int i = nObjects - 1; i >= 0; i--)
			{

				Delete(i);

			}

		}

		m_nObjects = 0;

	}

protected:

	void Extend()
	{

		TYPE **newArray = new TYPE *[m_maxSize * 2 + 1];
		memcpy(newArray, m_array, sizeof(TYPE *) * m_nObjects);

		delete[] m_array;

		m_array = newArray;
		m_maxSize *= 2;
		m_maxSize++;

	}

	void Condense()
	{

		TYPE **newArray = new TYPE *[m_maxSize / 2 + 1];
		memcpy(newArray, m_array, sizeof(TYPE *) * m_nObjects);

		delete[] m_array;

		m_array = newArray;
		m_maxSize /= 2;
		m_maxSize++;

	}

protected:

	TYPE **m_array;
	int m_maxSize;
	int m_nObjects;

};

#endif	// GR_DYNAMIC_ARRAY_H