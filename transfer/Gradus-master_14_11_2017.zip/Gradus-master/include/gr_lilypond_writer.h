#ifndef GR_LILYPOND_WRITER_H
#define GR_LILYPOND_WRITER_H

#include <fstream>

class grRhythymCounter
{

public:
    grRhythymCounter();
    ~grRhythymCounter();

    // Increment the rhythym counter
    void Increment(int numerator, int demoninator);

    // Set the time signature
    void SetTime(int numerator, int demoninator);

    // Split a note (should it cross the next bar line)
    void SplitNote(grNote *note, grNoteLength *currentBar, grNoteLength *nextBar) const;

private:

    // The numerator of the current meter
    int m_meterNumerator;

    // The denominator of the current meter
    int m_meterDenominator;

    // Current location of the cursor
    grNoteLength m_cursor;

    // Store the length of one bar
    grNoteLength m_barLength;

    // The current bar of the counter
    int m_currentBar;
    
};

class grMusicSnippet;
class grLilypondWriter
{

public:

    static const char *LILYPOND_VERSION = "2.18.2";

public:
    grLilypondWriter();
    ~grLilypondWriter();

    void WriteMusicSnippetToFile(grMusicSnippet *snippet, const char *fname);

private:
    // The file currently being written to
    std::fstream m_file;

private:

    void WriteLilypondHeader();
    void WriteVoice(grMusicSequence *sequence, grMusicSnippet *parent, int voiceNum);

};

#endif // GR_LILYPOND_WRITER_H