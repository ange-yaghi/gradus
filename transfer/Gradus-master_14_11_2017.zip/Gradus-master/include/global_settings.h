#ifndef GLOBAL_SETTINGS_H
#define GLOBAL_SETTINGS_H



#endif
