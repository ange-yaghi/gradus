#define BOOST_TEST_MODULE Gradus_SanityCheck
#define BOOST_TEST_ALTERNATIVE_INIT_API
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_SUITE(Gradus_SanityCheck);

BOOST_AUTO_TEST_CASE(SanityCheck)
{

	BOOST_TEST(true);

}

BOOST_AUTO_TEST_SUITE_END()