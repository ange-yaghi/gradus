# Gradus
Simple command line utility to teach music composition
